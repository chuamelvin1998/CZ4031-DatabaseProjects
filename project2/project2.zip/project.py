from interface import run_sql_query_compare

run_sql_query_compare()


